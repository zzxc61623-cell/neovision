package com.neovision.tv;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    // [base, blob1, blob2, blob3]
    private static final int[][] PALETTES = {
            {0xFF070B26, 0xFF3A7BFF, 0xFF8A2BE2, 0xFF00E5FF},
            {0xFF1A0A1F, 0xFFFF3D81, 0xFFFF9A3D, 0xFF8A2BE2},
            {0xFF021A1A, 0xFF00C48C, 0xFF00B4FF, 0xFF7CFFCB},
            {0xFF0B0B0B, 0xFFFFC857, 0xFFB8860B, 0xFF6D4C1D}
    };
    private static final String[] NAMES_AR = {"أزرق نيون", "غروب", "أورورا", "ذهبي"};
    private static final String[] NAMES_EN = {"Neon Blue", "Sunset", "Aurora", "Gold"};

    private boolean ar;
    private int palette;
    private BackgroundView bg;
    private TextView clock;
    private TextView dateView;
    private GridView grid;
    private AppAdapter adapter;
    private final List<Item> items = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    static class Item {
        String label;
        Drawable icon;
        Intent intent;
        boolean isTheme;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ar = "ar".equals(Locale.getDefault().getLanguage());
        palette = getSharedPreferences("neo", MODE_PRIVATE).getInt("palette", 0);
        if (palette < 0 || palette >= PALETTES.length) palette = 0;

        FrameLayout root = new FrameLayout(this);
        bg = new BackgroundView(this);
        bg.setPalette(PALETTES[palette]);
        root.addView(bg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(48), dp(32), dp(48), dp(24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = makeText("NEO VISION", 30, true);
        title.setLetterSpacing(0.15f);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout timeBox = new LinearLayout(this);
        timeBox.setOrientation(LinearLayout.VERTICAL);
        timeBox.setGravity(Gravity.END);
        clock = makeText("", 36, true);
        dateView = makeText("", 15, false);
        timeBox.addView(clock);
        timeBox.addView(dateView);
        header.addView(timeBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        col.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        grid = new GridView(this);
        grid.setNumColumns(6);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(14));
        grid.setVerticalSpacing(dp(14));
        grid.setClipToPadding(false);
        grid.setPadding(dp(6), dp(28), dp(6), dp(6));
        grid.setSelector(makeSelector());
        grid.setDrawSelectorOnTop(true);
        grid.setFocusable(true);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> onItemClicked(position));
        col.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        loadApps();
        grid.post(() -> grid.requestFocus());
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            nextPalette();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void updateClock() {
        Date d = new Date();
        clock.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(d));
        dateView.setText(DateFormat.getDateInstance(DateFormat.FULL).format(d));
    }

    private void nextPalette() {
        palette = (palette + 1) % PALETTES.length;
        getSharedPreferences("neo", MODE_PRIVATE).edit().putInt("palette", palette).apply();
        bg.setPalette(PALETTES[palette]);
        if (!items.isEmpty()) {
            items.set(0, makeThemeItem());
            adapter.notifyDataSetChanged();
        }
    }

    private Item makeThemeItem() {
        Item it = new Item();
        it.isTheme = true;
        String name = ar ? NAMES_AR[palette] : NAMES_EN[palette];
        it.label = (ar ? "الخلفية: " : "Theme: ") + name;
        int[] p = PALETTES[palette];
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{p[1], p[2], p[3]});
        g.setCornerRadius(dp(16));
        it.icon = g;
        return it;
    }

    private void loadApps() {
        items.clear();
        items.add(makeThemeItem());

        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        List<Item> apps = new ArrayList<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                Item it = new Item();
                CharSequence l = ri.loadLabel(pm);
                it.label = l == null ? pkg : l.toString();
                it.icon = ri.loadIcon(pm);
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(cat);
                launch.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                it.intent = launch;
                apps.add(it);
            }
        }
        Collections.sort(apps, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        items.addAll(apps);
        adapter.notifyDataSetChanged();
    }

    private void onItemClicked(int position) {
        if (position < 0 || position >= items.size()) return;
        Item it = items.get(position);
        if (it.isTheme) {
            nextPalette();
            return;
        }
        try {
            startActivity(it.intent);
        } catch (Exception ignored) {
            // app could not be launched
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        t.setShadowLayer(4f, 0f, 2f, 0x99000000);
        return t;
    }

    private Drawable makeSelector() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x33FFFFFF);
        g.setStroke(dp(3), Color.WHITE);
        g.setCornerRadius(dp(16));
        return g;
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Item it = items.get(position);
            LinearLayout cell = new LinearLayout(MainActivity.this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(8), dp(10), dp(8), dp(10));
            cell.setLayoutParams(new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(124)));

            ImageView iv = new ImageView(MainActivity.this);
            iv.setImageDrawable(it.icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            cell.addView(iv, new LinearLayout.LayoutParams(dp(64), dp(64)));

            TextView tv = makeText(it.label, 14, false);
            tv.setGravity(Gravity.CENTER);
            tv.setSingleLine(true);
            tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(8);
            cell.addView(tv, lp);
            return cell;
        }
    }

    /** Lightweight animated gradient background (cheap enough for weak TV GPUs). */
    static class BackgroundView extends View {
        private int[] pal = PALETTES[0];
        private final RadialGradient[] shaders = new RadialGradient[3];
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float radius;
        private final long start = System.currentTimeMillis();
        private static final float[] SPEED_X = {0.11f, 0.08f, 0.14f};
        private static final float[] SPEED_Y = {0.09f, 0.13f, 0.07f};
        private static final float[] PHASE = {0f, 2.1f, 4.2f};

        BackgroundView(android.content.Context c) {
            super(c);
        }

        void setPalette(int[] colors) {
            pal = colors;
            build();
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            build();
        }

        private void build() {
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0) return;
            radius = Math.max(w, h) * 0.5f;
            for (int i = 0; i < 3; i++) {
                int c = pal[i + 1];
                int transparent = c & 0x00FFFFFF;
                shaders[i] = new RadialGradient(0f, 0f, radius,
                        new int[]{c, (c & 0x00FFFFFF) | 0x55000000, transparent},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (shaders[0] == null) build();
            if (shaders[0] == null) return;
            canvas.drawColor(pal[0]);
            float t = (System.currentTimeMillis() - start) / 1000f;
            for (int i = 0; i < 3; i++) {
                float cx = w * (0.5f + 0.40f * (float) Math.sin(t * SPEED_X[i] + PHASE[i]));
                float cy = h * (0.5f + 0.40f * (float) Math.cos(t * SPEED_Y[i] + PHASE[i] * 1.3f));
                canvas.save();
                canvas.translate(cx, cy);
                paint.setShader(shaders[i]);
                canvas.drawCircle(0f, 0f, radius, paint);
                canvas.restore();
            }
            canvas.drawColor(0x33000000);
            postInvalidateDelayed(40);
        }
    }
}
